Thank you for downloading my tool.


You need node.js for this to work. You can download it here : (https://nodejs.org/en/download/)

1 : Put your http/socks5 proxies in the 'proxies' folder. 
2 : Open 0x29a'sGenAndChecker in a text editor
3 : Save the file
4 : Run/Open start.bat
5 : It will now generate and check the nitro codes. 

NOTE : Please be patient with this tool, though 60% of the codes are hits, it'll take a while to get a valid one.

ily.
-0x29a
