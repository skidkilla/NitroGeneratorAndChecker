if (process.platform === "win32") {
  var rl = require("readline").createInterface({
    input: process.stdin,
    output: process.stdout
  });

  rl.on("SIGINT", function () {
    process.emit("SIGINT");
  });
}

process.on("SIGINT", function () {
  console.log('\nChecked ' +i+' codes!\nFound '+a+' You got a working code, congrats.')
  process.exit();
});

const fs = require('fs');
const request = require('request');
const colors = require('colors')
const Agent = require('socks5-http-client/lib/Agent');
//Options
const codes = "workingcodes.txt";
const proxies = "proxies.txt";
const speed = 1000
const debug = false
let socks5 = false
const autogen = true
const noerrormessages = true 
const autograbproxy = true

let i = 0 //Don't fuck around with my code skid
let a = 0 //All rights go to skidkilla, A.K.A 0x29a.

if (autograbproxy) {
 socks5 = false
  request.get({
    uri: 'https://api.proxyscrape.com/?request=getproxies&proxytype=http&timeout=200',
}, function (err, resp, body) {
  fs.writeFile('proxies.txt', body, function(err) {
    if(err) {
        throw err;
    }

  });
});
}

console.log(colors.blue(`\n-------------------------------------\n[TOOL NAME] 0x29a'sGenAndChecker\n     [CREATOR] Author: 0x29a\n-------------------------------------\n              Settings\n-------------------------------------\n[CHECKER] Debug Mode: ${debug}\n[CHECKER] Socks5 Proxies: ${socks5}\n[CHECKER] Auto-Gen: ${autogen}\n[CHECKER] No Error Messages: ${noerrormessages}\n[CHECKER] Auto Grab Proxies: ${autograbproxy}\n-------------------------------------\n`))


getGiftCode = function () {
    let code = '';
    let dict = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for(var i = 0; i < 16; i++){
        code = code + dict.charAt(Math.floor(Math.random() * dict.length));
    }
    return code;
}

setInterval(function(){
function getRandomLine(filename, callback){
  fs.readFile(filename, function(err, data){
    if(err) throw err;
    data = data.toString()
    var lines = data.split('\n');
    var r = Math.floor(Math.random() * lines.length);
    callback(lines[r])
 });
}
if (autogen) {
let code = getGiftCode()
let proxy
getRandomLine(proxies, function(result){proxy = result; sendRequest();});
if (socks5) {
function sendRequest(){
request.get({
    uri: 'http://discordapp.com/api/v6/entitlements/gift-codes/'+code+'?with_application=false&with_subscription_plan=true',
    agentClass: Agent,
    agentOptions: {
		  socksHost: proxy.split(':')[0],
		  socksPort: proxy.split(':')[1]
	  }
}, function (err, resp, body) {
    if (err) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf!: ${err}`));
      }
    }
    try {
            body = JSON.parse(body);
            if(body.message != "Invalid Gift Code" && body.message != "Rate limit detected."){
                console.log(colors.green(`[CHECKER] Valid code detected!: https://discord.gift/${code}`));
                fs.appendFileSync("workingcodes.txt", code+'\n', "UTF-8",{'flags': 'a+'});
                i++
                a++
            }
            else {
                console.log(colors.Purple(`${code} - is invalid!` + colors.red(`${debug ? `\n[DEBUG] Proxy: ${proxy}\n[DEBUG] Message: ${body.message}` : ''}`)));
                i++
            }
        }
        catch (error) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf!: ${err}`));
      }
        }
});
}
} else {
function sendRequest(){
request.get({
    uri: 'http://discordapp.com/api/v6/entitlements/gift-codes/'+code+'?with_application=false&with_subscription_plan=true',
    proxy: 'http://'+proxy
}, function (err, resp, body) {
    if (err) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf!: ${err}`));
      }
    }
    try {
            body = JSON.parse(body);
            if(body.message != "Unknown Gift Code" && body.message != "Rate limit detected." && body.message != "404: Not Found"){
                console.log(colors.green(`[CHECKER] Code Found!: https://discord.gift/${code}`));
                fs.appendFileSync("workingcodes.txt", code+'\n', "UTF-8",{'flags': 'a+'});
                i++
                a++
            }
            else {
                console.log(colors.red(`${code} is invalid!` + colors.red(`${debug ? `\n[DEBUG] Proxy: ${proxy}\n[DEBUG] Message: ${body.message}` : ''}`)));
                i++
            }
        }
        catch (error) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf!: ${err}`));
      }
        }
});
}
}
} else {
let code
let proxy
getRandomLine(codes, function(result){code = result});
getRandomLine(proxies, function(result){proxy = result; sendRequest();});
if (socks5) {
function sendRequest(){
request.get({
    uri: 'http://discordapp.com/api/v6/entitlements/gift-codes/'+code+'?with_application=false&with_subscription_plan=true',
    agentClass: Agent,
    agentOptions: {
		  socksHost: proxy.split(':')[0],
		  socksPort: proxy.split(':')[1]
	  }
}, function (err, resp, body) {
    if (err) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf: ${err}`));
      }
    }
    try {
            body = JSON.parse(body);
            if(body.message != "Unknown Gift Code" && body.message != "Rate limit detected." && body.message != "404: Not Found"){
                console.log(colors.green(`[CHECKER] Code Found!: https://discord.gift/${code}`));
                fs.appendFileSync("workingcodes.txt", code+'\n', "UTF-8",{'flags': 'a+'});
                i++
                a++
            }
            else {
                console.log(colors.red(`${code} is invalid!` + colors.red(`${debug ? `\n[DEBUG] Proxy: ${proxy}\n[DEBUG] Message: ${body.message}` : ''}`)));
                i++
            }
        }
        catch (error) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf: ${err}`));
      }
        }
});
}
} else {
function sendRequest(){
request.get({
    uri: 'http://discordapp.com/api/v6/entitlements/gift-codes/'+code+'?with_application=false&with_subscription_plan=true',
    proxy: 'http://'+proxy
}, function (err, resp, body) {
    if (err) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf: ${err}`));
      }
    }
    try {
            body = JSON.parse(body);
            if(body.message != "Unknown Gift Code" && body.message != "Rate limit detected." && body.message != "404: Not Found"){
                console.log(colors.green(`[CHECKER] Code Found!: https://discord.gift/${code}`));
                fs.appendFileSync("workingcodes.txt", code+'\n', "UTF-8",{'flags': 'a+'});
                a++
                i++
            }
            else {
                console.log(colors.red(`${code} is invalid!` + colors.red(`${debug ? `\n[DEBUG] Proxy: ${proxy}\n[DEBUG] Message: ${body.message}` : ''}`)));
                i++
            }
        }
        catch (error) {
      if (!noerrormessages) {
        return console.log(colors.red(`The proxy trippin bro wtf!: ${err}`));
      }
        }
});
}
}
}


}, speed);